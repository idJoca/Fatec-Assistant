export {};

declare global {
  interface Window {watsonAssistantChatOptions: any}
}
