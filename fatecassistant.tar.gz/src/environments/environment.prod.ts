export const environment = {
  production: true,
  assistants: [
    {
      integrationId: '74be2c04-b7b9-4ad1-98a1-15f6e5173455',
      region: 'us-south',
      serviceInstanceId: '8f486940-cafc-4571-88f2-6ca198b06072',
      startMessage: 'Quero uma lista de monografias'
    },
    {
      integrationID: '6094d63f-7cd0-431e-989e-be0978fb8c7d',
      region: 'us-south',
      serviceInstanceID: '8f486940-cafc-4571-88f2-6ca198b06072',
      startMessage: 'Quero tirar dúvidas sobre Normas Técnicas'
    }
  ]
};
